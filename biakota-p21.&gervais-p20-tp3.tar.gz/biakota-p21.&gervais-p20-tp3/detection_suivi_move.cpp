#include "opencv2/video/tracking.hpp"
#include "opencv2/highgui/highgui.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <bits/basic_string.h>

#include <map>

using namespace cv;
using namespace std;

/*
 * Declarer la structure de la boite englobante minimale
 */
typedef struct {
	//Deux points pour dessiner la boite entourant l'objet
	Point p1;
	Point p2;
	//Index de l'objet pour distinguer des objets differents
	int numObjet;
} BoiteEnglobante;

/*
 * Construire l'image background
 */
void construireBackground (string nomVideo, Mat & background,  int nbFrame) {
	VideoCapture videoCap(nomVideo);
	if (!videoCap.isOpened()) {
		cout << "Impossible d'ouvrir la vidéo: " << nomVideo <<  "..." << endl;
		return;
	}
	int w = videoCap.get(CV_CAP_PROP_FRAME_WIDTH);
	int h = videoCap.get(CV_CAP_PROP_FRAME_HEIGHT);
	vector<Mat> sequence;
	int count = -1;
	// int nbFrame = videoCap.get(CV_CAP_PROP_FRAME_COUNT);
	cout <<videoCap.get(CV_CAP_PROP_FRAME_COUNT);
	while (true) {
		Mat frame;
		videoCap >> frame;
		if (!frame.data) {
			break;
		}
		count ++;
		//  if ((count >= frameInit) && (count < frameInit + nbFrame)) {
		Mat frameGray;
		cvtColor(frame, frameGray, CV_BGR2GRAY);
		sequence.push_back(frameGray);
		// }
	if (count >=  nbFrame) break;
	}
	//Verifier si nous avons 50 images pour construire le background
	if ((int)sequence.size() < nbFrame) return;
	//Initialiser l'image background
	background = Mat::zeros(h, w, CV_8UC1);
	for (int i = 0; i < background.rows; i++) {
		for (int j = 0; j < background.cols; j++) {
			int nbImage = sequence.size();
			//Mettre en ordre croissant une sequence de pixels
			int * sequencePixel = (int *)malloc(sizeof(int) * nbImage);
			for (int k = 0; k < nbImage; k++) {
				sequencePixel[k] = sequence[k].at<uchar>(i,j);
			}
			for (int k = 0; k < nbImage - 1; k++) {
				for (int l = k + 1; l < nbImage; l++) {
					if (sequencePixel[k] > sequencePixel[l]) {
						int tmp = 0;
						tmp = sequencePixel[k];
						sequencePixel[k] = sequencePixel[l];
						sequencePixel[l] = tmp;
					}
				}
			}
			//Prendre le median de la sequence de pixel
			background.at<uchar>(i,j) = sequencePixel[(nbImage + 1) / 2];
			delete [] sequencePixel;
		}
	}
	//Save image background
	imwrite(nomVideo + "_background.png", background);
}

/*
 * Enlever du bruit, Fermer des trous... pour l'image de detection du mouvement
 */
void pretraitementDetection (Mat &imgTraite, int seuil) {
	//Appliquer Canny pour trouver des contours
	Mat imgMvt = imgTraite.clone();
	Mat imgCanny;
	Canny(imgMvt, imgCanny, 10, 170, 3, false);
	//Enlever du bruit
	Mat imgSansBruit = imgCanny.clone();
	int w = imgCanny.cols & -2;
	int h = imgCanny.rows & -2;
	Size sizeTmp = Size(w/2, h/2);
	Mat tmp = Mat::zeros(sizeTmp, imgCanny.type());
	pyrDown(imgSansBruit, tmp, sizeTmp);
	pyrUp(tmp, imgSansBruit, Size(imgCanny.cols, imgCanny.rows));
	//prendre des composantes connexes par la fonction floodFill()
	Mat imgComposantConnexe = imgSansBruit.clone();
	floodFill(imgComposantConnexe, Point(0,0), Scalar::all(0xFFFFFF));
	//recuperer l'image binaire qui contient des objets en mouvement
	Mat imgConnexe = imgComposantConnexe.clone();
	threshold(imgConnexe, imgConnexe, 254, 255, CV_THRESH_BINARY_INV);
	//Enlever du bruit
	vector< vector<Point> > contours;
	Mat imgContour = imgConnexe.clone();
	findContours(imgContour, contours, CV_RETR_CCOMP, CV_CHAIN_APPROX_SIMPLE);
	for (int i = 0; i < (int)contours.size(); i++) {
		//Enlever si le nombre de pixel < seuil
		if ((int)contours[i].size() < seuil) {
			Mat pointMat(contours[i]);
			//Pour chaque contour, determiner le rectangle entourant
			Rect rect = boundingRect(pointMat);
			for (int k = rect.y; k <= rect.y + rect.height; k++) {
				for (int l = rect.x; l <= rect.x + rect.width; l++) {
					imgConnexe.at<uchar>(k,l) = 0;
				}
			}
		}
	}
	//    imwrite("traiter/imgConnexe.png", imgConnexe);
	//Erode et Dilate
	Mat imgErode = imgConnexe.clone();
	erode(imgErode, imgErode, Mat(), Point(-1,-1), 3);
	Mat imgDilate = Mat::zeros(imgErode.size(), imgErode.type());
	dilate(imgErode, imgDilate, Mat(), Point(-1, -1), 1);
	imgTraite = imgDilate.clone();
}

/*
 * Determiner des boites englobantes minimales entourant les objets en mouvement
 */
vector<BoiteEnglobante> determinerBoite(const Mat &currentFrame, int seuil) {
	//Declarer la liste des boites, chacune pour chaque objet en mouvement dans l'image
	vector<BoiteEnglobante> boiteObjets;
	boiteObjets.clear();
	//Chaque contour d'un objet en mouvement est represente par une liste de points
	vector< vector<Point> > contours;
	//Trouver tous les contours dans le frame courant
	Mat imgContour = currentFrame.clone();
	findContours(imgContour, contours, CV_RETR_CCOMP, CV_CHAIN_APPROX_SIMPLE);
	for (int i = 0; i < (int)contours.size(); i++) {
		if ((int)contours[i].size() >= seuil) {
			//Transformer le vecteur de points en matrice de points
			Mat pointMat(contours[i]);
			//Pour chaque contour, determiner le rectangle entourant
			Rect rect = boundingRect(pointMat);
			BoiteEnglobante boite;
			boite.p1.x = rect.x;
			boite.p1.y = rect.y;
			boite.p2.x = rect.x + rect.width;
			boite.p2.y = rect.y + rect.height;
			boite.numObjet = -1;//pas encore avoir l'etiquette
			boiteObjets.push_back(boite);
		}
	}
	return boiteObjets;
}

/*
 * Dessiner des boites entourant des objets en mouvement
 */
void dessinerBoite(Mat &currentFrame, vector<BoiteEnglobante> boiteObjets) {
	//Utiliser le vert pour dessiner des boites entourant des objets
	for (int i = 0; i < (int)boiteObjets.size(); i++) {
		rectangle(currentFrame, boiteObjets[i].p1, boiteObjets[i].p2, CV_RGB(255, 0, 0), 1);
	}
}

/*
 * Dessiner le trajectoire pour la prediction
 */
void draw_cross(Mat &imgSuivi, Point centre, int d, const Scalar& color) {
	//La forme est x pour chaque point
	line(imgSuivi, Point(centre.x - d, centre.y -d), Point(centre.x + d, centre.y + d), color, 1, 0);
	line(imgSuivi, Point(centre.x + d, centre.y -d), Point(centre.x - d, centre.y + d), color, 1, 0);
}

/*
 * Dessiner le trajectoire pour le mesurement
 */
void draw_cercle(Mat &imgSuivi, Point centre, int d, const Scalar& color) {
	circle(imgSuivi, centre, d, color, 1, 0);
}

/*
 * Dessiner le trajectoire pour la correction
 */
void draw_carre(Mat &imgSuivi, Point centre, int d, const Scalar& color) {
	rectangle(imgSuivi, Point(centre.x - d, centre.y -d), Point(centre.x + d, centre.y + d), color, 1, 0);
}

/*
 * Trouver l'objet correspondant dans le frame suivant
 */
int rechercheCorrespondance(int x, int y, vector<BoiteEnglobante> boiteObjets, int seuil) {
	int correspondanceIndex = -1;
	int min = 1000000;
	for (int i = 0; i < (int)boiteObjets.size(); i++) {
		int centreX = (boiteObjets[i].p1.x + boiteObjets[i].p2.x) / 2;
		int centreY = (boiteObjets[i].p1.y + boiteObjets[i].p2.y) / 2;
		//Si le point centre (x,y) de l'objet a rechercher sa correspondance est
		//dans la fenetre
		if ((x >= centreX - seuil) && (x <= centreX + seuil) && (y >= centreY - seuil) && (y <= centreY + seuil)) {
			//Trouver ce qui a la distance minimal par rapport au point centre (centreX, centreY)
			int distance = (centreX - x) * (centreX - x) + (centreY - y) * (centreY - y);
			if (distance < min) {
				min = distance;
				correspondanceIndex = i;
			}
		}
	}
	return correspondanceIndex;
}

/*
 * Initialise les kalman Filter pour des objets en mouvement dans le frame
 */
void kalmanFilter(map<int, KalmanFilter> &listKalmanFilter, vector<BoiteEnglobante> &boiteObjets, int nbParamState, int nbParamMesure, int w, int h) {
	//Pour chaque objet dans la boite, etiqueter et initialiser le filtre kalman
	int maxIndex = -1;
	//Trouver l'index maximal de l'objet dans la liste
	for (int i = 0; i < (int)boiteObjets.size(); i++) {
		if (maxIndex < boiteObjets[i].numObjet) {
			maxIndex = boiteObjets[i].numObjet;
		}
	}
	//Etiquette pour des objets ayant numObjet = -1
	//Mesurer deux parametres seulement: x et y
	Mat mesurement = Mat::zeros(nbParamMesure, 1, CV_32FC1);
	//Declarer une image pour contenir tous les traces de tous les objets en mouvement
	Mat imgSuiviMouvement = imread("suivi.png", -1);
	for (int i = 0; i < (int)boiteObjets.size(); i++) {
		if (boiteObjets[i].numObjet == -1)
		{   //C'est le nouvel objet, pas ayant le filtre Kalman,
			//on va initialiser un filtre Kalman pour suivre le mouvement de cet objet
			maxIndex++;
			boiteObjets[i].numObjet = maxIndex;
			//Initialiser le filter Kalman
			KalmanFilter kalman(nbParamState, nbParamMesure, 0);
			//Initialiser des matrices
			setIdentity(kalman.transitionMatrix, cvRealScalar(1));
			kalman.transitionMatrix.at<float>(0,2) = 1;
			kalman.transitionMatrix.at<float>(1,3) = 1;
			setIdentity(kalman.processNoiseCov, cvRealScalar(0));
			setIdentity(kalman.measurementNoiseCov, cvRealScalar(0));
			setIdentity(kalman.measurementMatrix, cvRealScalar(1));
			setIdentity(kalman.errorCovPost, cvRealScalar(1));
			//Faire la prediction, pas encore avoir les donnees historiques
			Mat predictionMat = kalman.predict();

			//Faire le mesurement
			//Calculer le point au centre de la boite englobante
			mesurement.at<float>(0,0) = (boiteObjets[i].p2.x + boiteObjets[i].p1.x) / 2;
			mesurement.at<float>(1,0) = (boiteObjets[i].p2.y + boiteObjets[i].p1.y) / 2;
			//La vitesse vx, vy
			mesurement.at<float>(2,0) = 0;
			mesurement.at<float>(3,0) = 0;

			//Faire la correction
			Mat correctionMat = kalman.correct(mesurement);

			//Pour chaque objet, initialiser une image suivi
			Mat imgSuivi;
			stringstream ss;
			ss << "objet_suivi/objet_" << boiteObjets[i].numObjet << ".png";
			string filename = ss.str();
			imgSuivi = imread(filename, -1);
			if (!imgSuivi.data) {
				imgSuivi = Mat::zeros(h, w, CV_8UC3);
			}

			//Dessiner le trajectoire de prediction
			draw_cross(imgSuivi, Point(predictionMat.at<float>(0,0), predictionMat.at<float>(1,0)), 3, CV_RGB(0, 0, 255));
			draw_cross(imgSuiviMouvement, Point(predictionMat.at<float>(0,0), predictionMat.at<float>(1,0)), 3, CV_RGB(0, 0, 255));
			//Dessiner le trajectoire de mesurement
			draw_cercle(imgSuivi, Point(mesurement.at<float>(0,0), mesurement.at<float>(1,0)), 3, CV_RGB(0, 255, 0));
			draw_cercle(imgSuiviMouvement, Point(mesurement.at<float>(0,0), mesurement.at<float>(1,0)), 3, CV_RGB(0, 255, 0));
			//Dessiner le trajectoire de correction
			draw_carre(imgSuivi, Point(correctionMat.at<float>(0,0), correctionMat.at<float>(1,0)), 3, CV_RGB(255, 0, 0));
			draw_carre(imgSuiviMouvement, Point(correctionMat.at<float>(0,0), correctionMat.at<float>(1,0)), 3, CV_RGB(255, 0, 0));
			//Dessiner text dans l'image suivi de mouvement
			stringstream ssText;
			ssText << boiteObjets[i].numObjet;
			string text = ssText.str();
			int fontFace = CV_FONT_HERSHEY_SIMPLEX;
			double fontScale = 0.5;
			int thickness = 1;
			int x = (boiteObjets[i].p1.x + boiteObjets[i].p2.x) / 2;
			int y = (boiteObjets[i].p1.y + boiteObjets[i].p2.y) / 2;
			Point textPosition(x,y);
			putText(imgSuivi, text, textPosition, fontFace, fontScale, CV_RGB(255, 255, 255), thickness, 8);

			//Enregistrer l'image suivi pour cet objet
			imwrite(filename, imgSuivi);
			//Ajouter le filter kalman a la liste des filtres
			listKalmanFilter[boiteObjets[i].numObjet] = kalman;
		}
	}
	imwrite("suivi.png", imgSuiviMouvement);
}

/*
 * main function
 */
int main(int argc, char** argv) {
	String  nomVideo=argv[1];
	int nbFrameCaptureParSeconde = atoi(argv[2]);//5
	int seuilDifference = atoi(argv[3]);//60
	int seuilBruit=atoi(argv[4]); //30
	int seuilCorrespondant=atoi(argv[5]); //80
	int nbFrame = 50;
	//Nombre de parametres state: x, y, vx, vy
	int nbParamState = 4;
	int nbParamMesure = 4; //x, y, vx, vy sont mesures


	//Ouvrir le video fichier
	VideoCapture videoCap(nomVideo);
	if (!videoCap.isOpened()) {
		cout << "Impossible d'ouvrir la vidéo: " << nomVideo <<  "..." << endl;
		return (EXIT_FAILURE);
	}


	//Recuperer Frame-Rate - le nombre d'images par seconde du video
	int frameRate = videoCap.get(CV_CAP_PROP_FPS);

	//Calculer la frequence de capturer des images du video
	int dureeCapture = frameRate / nbFrameCaptureParSeconde;

	//La taille du video
	int w = videoCap.get(CV_CAP_PROP_FRAME_WIDTH);
	int h = videoCap.get(CV_CAP_PROP_FRAME_HEIGHT);

	//Declarer des images background, mouvement
	Mat imgBG;
	Mat imgMvt;

	//Declarer des matrices floating point pour des images: image capturee, background et mouvement
	Mat matriceBG;
	Mat matriceFrame;
	Mat matriceMvt;
	//Declarer une image qui contient tous les traces de tous les objets en mouvement dans le video
	Mat imgSuiviMouvement;

	//Vecteur des objets en mouvement du frame courant
	vector<BoiteEnglobante> objetCourants;
	objetCourants.clear();
	//Vecteur des objets en mouvement du frame precedent
	vector<BoiteEnglobante> previousBoiteObjets;
	previousBoiteObjets.clear();

	//List Kalmal filter des objets en mouvement
	map<int, KalmanFilter> listKalmanFilter;
	listKalmanFilter.clear();

	//numero des images de mouvement
	int index = 0;
	//Index du frame courant
	int numFrameCourant = -1;

	//Initialiser des fenetres pour afficher des resultats
	namedWindow("Video_BoiteEnglobante", 1);

	namedWindow("Image Mouvement", 1);
	namedWindow("Suivi", 1);
	// Construction bg
	construireBackground(nomVideo, imgBG, nbFrame);
	namedWindow("Image Background", 1);
	imshow("Image Background", imgBG);
	while (1){
		Mat frame;
		//Recuperer une nouvelle image
		//En fonction du video, image capturee est en couleur ou en niveau de gris
		videoCap >> frame;
		if (!frame.data) {
			break;
		}
		numFrameCourant = numFrameCourant + 1;

		//Verifier si on capture cette image ou non
		if (numFrameCourant % dureeCapture == 0){
			if (numFrameCourant == 0) {
				//Initialiser des images et des matrices
				//Image en niveau de gris pour mouvement
				imgMvt = Mat::zeros(frame.size(), CV_8UC1);
				imgSuiviMouvement = Mat::zeros(frame.size(), CV_8UC3);
				imwrite("suivi.png", imgSuiviMouvement);
				//Transformer l'image capturee en niveau de gris
				cvtColor(frame, imgMvt, CV_BGR2GRAY);
				//Transformer des images en des matrices
				imgBG.convertTo(matriceBG, CV_32FC1);
				imgMvt.convertTo(matriceMvt, CV_32FC1);
				imgMvt.convertTo(matriceFrame, CV_32FC1);
				index ++;
			}
			else {
				//Detecter le mouvement
				cvtColor(frame, imgMvt, CV_BGR2GRAY);
				imgMvt.convertTo(matriceFrame, CV_32FC1);
				imgBG.convertTo(matriceBG, CV_32FC1);
				//Decter le mouvement en utilisant la difference entre
				//l'image background et l'image capturee
				absdiff(matriceFrame, matriceBG, matriceMvt);
				threshold(matriceMvt, imgMvt, seuilDifference, 255.0, CV_THRESH_BINARY);
				Mat imgTraite;
				imgMvt.convertTo(imgTraite, CV_8UC1);
				pretraitementDetection(imgTraite, seuilBruit);
				//Determiner des boites englobantes minimales
				objetCourants = determinerBoite(imgTraite, seuilBruit);
				//Suivi mouvement
				//Si c'est le premier frame
				if ((previousBoiteObjets.size() == 0) && (objetCourants.size() > 0)) {
					//Initialiser les filtres pour tous les objets
					kalmanFilter(listKalmanFilter, objetCourants, 4, 4, w, h);
					previousBoiteObjets = objetCourants;
				}
				else
				{ //Les frames suivants
					//Ouvrir l'image qui contient tous les traces de tous les objets en mouvement
					imgSuiviMouvement = imread("suivi.png", -1);
					for (int i = 0; i < (int)previousBoiteObjets.size(); i++) {
						//1. Faire la prediction
						Mat predictionMat = listKalmanFilter[previousBoiteObjets[i].numObjet].predict();

						stringstream ss;
						ss << "objet_suivi/objet_" << previousBoiteObjets[i].numObjet << ".png";
						string fileName = ss.str();
						Mat imgSuivi = imread(fileName, -1);

						//Dessiner le trajectoire de prediction
						draw_cross(imgSuivi, Point(predictionMat.at<float>(0,0), predictionMat.at<float>(1,0)), 3, CV_RGB(255, 0, 0));
						draw_cross(imgSuiviMouvement, Point(predictionMat.at<float>(0,0), predictionMat.at<float>(1,0)), 3, CV_RGB(255, 0, 0));

						//2. Chercher des correspondances
						int correspondance = rechercheCorrespondance(predictionMat.at<float>(0,0), predictionMat.at<float>(1,0), objetCourants, seuilCorrespondant);
						if (correspondance != -1)
						{//Si trouver l'objet correspondant
							//Assigner l'index correspondant
							objetCourants[correspondance].numObjet = previousBoiteObjets[i].numObjet;
							//Faire le mesurement
							Mat mesurement = Mat::zeros(nbParamMesure, 1, CV_32FC1);
							//La position observee
							mesurement.at<float>(0,0) = (objetCourants[correspondance].p1.x + objetCourants[correspondance].p2.x) / 2;
							mesurement.at<float>(1,0) = (objetCourants[correspondance].p1.y + objetCourants[correspondance].p2.y) / 2;
							//La vitesse calculee
							float vx = 0;
							float vy = 0;
							vx = ((objetCourants[correspondance].p1.x + objetCourants[correspondance].p2.x) / 2) -
									((previousBoiteObjets[i].p1.x + previousBoiteObjets[i].p2.x) / 2);
							vy = ((objetCourants[correspondance].p1.y + objetCourants[correspondance].p2.y) / 2) -
									((previousBoiteObjets[i].p1.y + previousBoiteObjets[i].p2.y) / 2);
							mesurement.at<float>(2,0) = vx;
							mesurement.at<float>(3,0) = vy;
							//Faire la correction
							Mat correctionMat = listKalmanFilter[previousBoiteObjets[i].numObjet].correct(mesurement);

							//Afficher et enregistrer les resultats suivi du mouvement
							//Dessiner le trajectoire de mesurement
							draw_cercle(imgSuivi, Point(mesurement.at<float>(0,0), mesurement.at<float>(1,0)), 3, CV_RGB(0, 255, 0));
							draw_cercle(imgSuiviMouvement, Point(mesurement.at<float>(0,0), mesurement.at<float>(1,0)), 3, CV_RGB(0, 255, 0));
							//Dessiner le trajectoire de correction
							draw_carre(imgSuivi, Point(correctionMat.at<float>(0,0), correctionMat.at<float>(1,0)), 3, CV_RGB(0, 0, 255));
							draw_carre(imgSuiviMouvement, Point(correctionMat.at<float>(0,0), correctionMat.at<float>(1,0)), 3, CV_RGB(0, 0, 255));
							//Dessiner les trois trajectoire sur le frame courant
							draw_cross(frame, Point(predictionMat.at<float>(0,0), predictionMat.at<float>(1,0)), 3, CV_RGB(255, 0, 0));
							//Dessiner le trajectoire de mesurement
							draw_cercle(frame, Point(mesurement.at<float>(0,0), mesurement.at<float>(1,0)), 3, CV_RGB(0, 255, 0));
							//Dessiner le trajectoire de correction
							draw_carre(frame, Point(correctionMat.at<float>(0,0), correctionMat.at<float>(1,0)), 3, CV_RGB(0, 0, 255));
							//Enregistrer l'image suivi pour cet objet
							imwrite(fileName, imgSuivi);
						}
					}
					//3. Initialiser Kalman Filter pour de nouveaux objets (ce qui ayant numObjet = -1)
					kalmanFilter(listKalmanFilter, objetCourants, nbParamState, nbParamMesure, w, h);
					previousBoiteObjets = objetCourants;
				}

				//Dessiner des boites sur l'image correspondante
				dessinerBoite(frame, objetCourants);
				//Ajouter les noms des objets en mouvement dans le frame courant
				for (int i = 0; i < (int)objetCourants.size(); i++) {
					stringstream s;
					s << objetCourants[i].numObjet;
					string text = s.str();
					int fontFace = CV_FONT_HERSHEY_SIMPLEX;
					double fontScale = 0.5;
					int thickness = 1;
					int x = (objetCourants[i].p1.x + objetCourants[i].p2.x) / 2;
					int y = (objetCourants[i].p1.y + objetCourants[i].p2.y) / 2;
					Point textPosition(x,y);
					putText(frame, text, textPosition, fontFace, fontScale, CV_RGB(0, 0, 255), thickness, 8);
				}
				//Enregistrer les resultats
				stringstream ssFileName;
				ssFileName << nomVideo << "_dectection_" << index << ".png";
				string fileNameTmp = ssFileName.str();
				string mouvementFileName = "image_detecte/" + fileNameTmp;
				string frameFileName = "frame/" + fileNameTmp;
				imwrite(mouvementFileName, imgTraite);
				imwrite(frameFileName, frame);
				imwrite("suivi.png", imgSuiviMouvement);
				imshow("Suivi", imgSuiviMouvement);
				imshow("Video_BoiteEnglobante", frame);
				imshow("Image Mouvement", imgTraite);

				index ++;
			}
		}
		waitKey(10);
	}

	return (EXIT_SUCCESS);
}


